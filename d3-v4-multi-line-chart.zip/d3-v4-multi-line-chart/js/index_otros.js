var wh_sala =[
  {
    name: "Botellero",
    values:[
      { date: "01:00", value: "131" },
      { date: "02:00", value: "111" },
      { date: "03:00", value: "124" },
      { date: "04:00", value: "121" },
      { date: "05:00", value: "93" },
      { date: "06:00", value: "55"},
      { date: "07:00", value: "137" },
      { date: "08:00", value: "101" },
      { date: "09:00", value: "115" },
      { date: "10:00", value: "214"},
      { date: "11:00", value: "172" },
      { date: "12:00", value: "171" },
      { date: "13:00", value: "136" },
      { date: "14:00", value: "127"},
      { date: "15:00", value: "97" },
      { date: "16:00", value: "61" },
      { date: "17:00", value: "169" },
      { date: "18:00", value: "132" },
      { date: "19:00", value: "113" },
      { date: "20:00", value: "139" },
      { date: "21:00", value: "105"},
      { date: "22:00", value: "86"},
      { date: "23:00", value: "69" },
      { date: "24:00", value: "151" }
    ]
  }
];
var wh_sala_temperatura =[
  {
    name: "Temperatura",
    values:[
      { date: "1", value: "28" },
      { date: "2", value: "28" },
      { date: "3", value: "28" },
      { date: "4", value: "28" },
      { date: "5", value: "27" },
      { date: "6", value: "25"},
      { date: "7", value: "25" },
      { date: "8", value: "24" },
      { date: "9", value: "25" },
      { date: "10", value: "26"},
      { date: "11", value: "27" },
      { date: "12", value: "27" },
      { date: "13", value: "28" },
      { date: "14", value: "27"},
      { date: "15", value: "27" },
      { date: "16", value: "27" },
      { date: "17", value: "26" },
      { date: "18", value: "26" },
      { date: "19", value: "25" },
      { date: "20", value: "25" },
      { date: "21", value: "24"},
      { date: "22", value: "26"},
      { date: "23", value: "26" },
      { date: "24", value: "27" }
    ]
  },
  {
    name: "FGSD",
    values:[
      { date: "1", value: "0" },
      { date: "2", value: "0" },
      { date: "3", value: "0" },
      { date: "4", value: "0" },
      { date: "5", value: "0" },
      { date: "6", value: "26"},
      { date: "7", value: "0" },
      { date: "8", value: "25" },
      { date: "9", value: "0" },
      { date: "10", value: "27"},
      { date: "11", value: "28" },
      { date: "12", value: "0" },
      { date: "13", value: "0" },
      { date: "14", value: "0"},
      { date: "15", value: "0" },
      { date: "16", value: "0" },
      { date: "17", value: "27" },
      { date: "18", value: "0" },
      { date: "19", value: "0" },
      { date: "20", value: "0" },
      { date: "21", value: "0"},
      { date: "22", value: "0"},
      { date: "23", value: "0" },
      { date: "24", value: "0" }
    ]
  }
];
var wh_sala_fgsd =[
  {
    name: "FGSD-002",
    values:[
      { date: "1", value: "0" },
      { date: "2", value: "0" },
      { date: "3", value: "0" },
      { date: "4", value: "0" },
      { date: "5", value: "0" },
      { date: "6", value: "26"},
      { date: "7", value: "0" },
      { date: "8", value: "25" },
      { date: "9", value: "0" },
      { date: "10", value: "28"},
      { date: "11", value: "0" },
      { date: "12", value: "0" },
      { date: "13", value: "0" },
      { date: "14", value: "0"},
      { date: "15", value: "0" },
      { date: "16", value: "0" },
      { date: "17", value: "27" },
      { date: "18", value: "0" },
      { date: "19", value: "0" },
      { date: "20", value: "0" },
      { date: "21", value: "0"},
      { date: "22", value: "0"},
      { date: "23", value: "0" },
      { date: "24", value: "0" }
    ]
  }
];
var sem_altillo_signal=[
  {
  name: "NEVERA_ALTA_1",
  values: [
    { date: "1", value: "0" },
    { date: "2", value: "52" },
    { date: "3", value: "64" },
    { date: "4", value: "36" },
    { date: "5", value: "44" },
    { date: "6", value: "2"},
    { date: "7", value: "0" }
]
},
{
name: "Arcon n2 final",
values: [
  { date: "1", value: "0" },
  { date: "2", value: "50" },
  { date: "3", value: "36" },
  { date: "4", value: "2" },
  { date: "5", value: "6" },
  { date: "6", value: "4"},
  { date: "7", value: "0" }
]
},
{
name: "Nevera alta n1",
values: [
  { date: "1", value: "0" },
  { date: "2", value: "50" },
  { date: "3", value: "28" },
  { date: "4", value: "0" },
  { date: "5", value: "2" },
  { date: "6", value: "0"},
  { date: "7", value: "0" }
]
}
]
var sem_altillo_con=[
  {
  name: "Nevera alta n1",
  values: [
    { date: "1", value: "12632"},
    { date: "2", value: "2247" },
    { date: "3", value: "2423" },
    { date: "4", value: "2248"},
    { date: "5", value: "2359"},
    { date: "6", value: "2163" },
    { date: "7", value: "2134"}
]
}
];
var wh_horno =[
  {
    name: "Horno",
    values: [
      { date: "1", value: "0" },
      { date: "2", value: "0" },
      { date: "3", value: "0" },
      { date: "4", value: "0" },
      { date: "5", value: "2379" },
      { date: "6", value: "2641"},
      { date: "7", value: "0" },
      { date: "8", value: "0" },
      { date: "9", value: "0" },
      { date: "10", value: "969"},
      { date: "11", value: "753" },
      { date: "12", value: "2585" },
      { date: "13", value: "915" },
      { date: "14", value: "0"},
      { date: "15", value: "0" },
      { date: "16", value: "0" },
      { date: "17", value: "0" },
      { date: "18", value: "0" },
      { date: "19", value: "0" },
      { date: "20", value: "0" },
      { date: "21", value: "0"},
      { date: "22", value: "0"},
      { date: "23", value: "0" },
      { date: "24", value: "0" }
    ]
  }
]
var horno_signal=[
  {
    name: "Horno",
    values: [
      { date: "1", value: "0" },
      { date: "2", value: "0" },
      { date: "3", value: "0" },
      { date: "4", value: "0" },
      { date: "5", value: "7" },
      { date: "6", value: "5"},
      { date: "7", value: "0" },
      { date: "8", value: "0" },
      { date: "9", value: "0" },
      { date: "10", value: "5"},
      { date: "11", value: "1" },
      { date: "12", value: "22" },
      { date: "13", value: "6" },
      { date: "14", value: "0"},
      { date: "15", value: "0" },
      { date: "16", value: "0" },
      { date: "17", value: "0" },
      { date: "18", value: "0" },
      { date: "19", value: "0" },
      { date: "20", value: "0" },
      { date: "21", value: "0"},
      { date: "22", value: "0"},
      { date: "23", value: "0" },
      { date: "24", value: "0" }
    ]
  }
]

var wh_aire =[
  {
    name: "Aire1",
    values:[
      { date: "1", value: "0" },
      { date: "2", value: "0" },
      { date: "3", value: "0" },
      { date: "4", value: "0" },
      { date: "5", value: "470.03" },
      { date: "6", value: "3667.82"},
      { date: "7", value: "741.30" },
      { date: "8", value: "3851.29" },
      { date: "9", value: "904.79" },
      { date: "10", value: "3730.14"},
      { date: "11", value: "4225.50" },
      { date: "12", value: "4221.68" },
      { date: "13", value: "4253.42" },
      { date: "14", value: "4160.82"},
      { date: "15", value: "4149.86" },
      { date: "16", value: "4179.72" },
      { date: "17", value: "4130.50" },
      { date: "18", value: "4092.10" },
      { date: "19", value: "3714.75" },
      { date: "20", value: "3642.07" },
      { date: "21", value: "3412.52"},
      { date: "22", value: "0"},
      { date: "23", value: "0" },
      { date: "24", value: "0" }
    ]
  },
  {
    name: "Aire2",
    values:[
      { date: "1", value: "0" },
      { date: "2", value: "0" },
      { date: "3", value: "0" },
      { date: "4", value: "0" },
      { date: "5", value: "8.29" },
      { date: "6", value: "75.42"},
      { date: "7", value: "12.82" },
      { date: "8", value: "0" },
      { date: "9", value: "0" },
      { date: "10", value: "0.23"},
      { date: "11", value: "0" },
      { date: "12", value: "0" },
      { date: "13", value: "0" },
      { date: "14", value: "0"},
      { date: "15", value: "0" },
      { date: "16", value: "0" },
      { date: "17", value: "0" },
      { date: "18", value: "0" },
      { date: "19", value: "0" },
      { date: "20", value: "0" },
      { date: "21", value: "0"},
      { date: "22", value: "0"},
      { date: "23", value: "0" },
      { date: "24", value: "0" }
    ]
  },
  {
    name: "Aire3",
    values:[
      { date: "1", value: "0" },
      { date: "2", value: "0" },
      { date: "3", value: "0" },
      { date: "4", value: "0" },
      { date: "5", value: "243.92" },
      { date: "6", value: "2134.03"},
      { date: "7", value: "1109.91" },
      { date: "8", value: "0" },
      { date: "9", value: "0" },
      { date: "10", value: "0.23"},
      { date: "11", value: "0" },
      { date: "12", value: "0" },
      { date: "13", value: "0" },
      { date: "14", value: "0"},
      { date: "15", value: "0" },
      { date: "16", value: "0" },
      { date: "17", value: "0" },
      { date: "18", value: "0" },
      { date: "19", value: "0" },
      { date: "20", value: "0" },
      { date: "21", value: "0"},
      { date: "22", value: "0"},
      { date: "23", value: "0" },
      { date: "24", value: "0" }
    ]
  }

];
var signal_aire =[
  {
    name: "aire1/aire3",
    values: [
      { date: "1", value: "0" },
      { date: "2", value: "0" },
      { date: "3", value: "0" },
      { date: "4", value: "0" },
      { date: "5", value: "1" },
      { date: "6", value: "0"},
      { date: "7", value: "0" },
      { date: "8", value: "0" },
      { date: "9", value: "0" },
      { date: "10", value: "0"},
      { date: "11", value: "0" },
      { date: "12", value: "0" },
      { date: "13", value: "0" },
      { date: "14", value: "0"},
      { date: "15", value: "0" },
      { date: "16", value: "0" },
      { date: "17", value: "0" },
      { date: "18", value: "0" },
      { date: "19", value: "0" },
      { date: "20", value: "0" },
      { date: "21", value: "0"},
      { date: "22", value: "1"},
      { date: "23", value: "0" },
      { date: "24", value: "0" }
    ]
  }
];


var width = 1000;
var height = 450;
var margin = 90;
var mar2 = 80;
var duration = 250;

var lineOpacity = "0.25";
var lineOpacityHover = "0.85";
var otherLinesOpacityHover = "0.1";
var lineStroke = "3px";
var lineStrokeHover = "3.5px";

var circleOpacity = '0.85';
var circleOpacityOnLineHover = "0.25"
var circleRadius = 3;
var circleRadiusHover = 6;
var axistransform1=width-margin;
var axistransform2=axistransform1+40;

/* Format Data */
var parseDate1 = d3.timeParse("%d")

var parseDate = d3.timeParse("%H");


wh_sala_temperatura.forEach(function(d) {
  d.values.forEach(function(d) {
    d.date = parseDate(d.date);
  });
});
wh_horno.forEach(function(d) {
  d.values.forEach(function(d) {
    d.date = parseDate(d.date);
  });
});
horno_signal.forEach(function(d) {
  d.values.forEach(function(d) {
    d.date = parseDate(d.date);
  });
});
wh_aire.forEach(function(d) {
  d.values.forEach(function(d) {
    d.date = parseDate(d.date);
  });
});
signal_aire.forEach(function(d) {
  d.values.forEach(function(d) {
    d.date = parseDate(d.date);
  });
});
var xScale = d3.scaleTime()
  .domain(d3.extent(wh_horno[0].values, d => d.date))
  .range([0, width-margin]);
var xScale_sem = d3.scaleLinear()
  .domain(d3.extent(sem_altillo_con[0].values, d => d.date))
  .range([0, width-margin]);
var yScale_sem_altillo = d3.scaleLinear()
  .domain([0, 13000])
  .range([height-margin, 0]);
var nyScale_sem_altillo = d3.scaleLinear()
  .domain([0, 70])
  .range([height-margin, 0]);

var nyScale_sala_temperatura = d3.scaleLinear()
    .domain([0,30])
    .range([height-margin, 0]);

var yScale_aire_temp = d3.scaleLinear()
    .domain([0,2750])
    .range([height-margin, 0]);
var nyScale_aire_temp= d3.scaleLinear()
    .domain([0,25])
    .range([height-margin, 0]);
var yScale_aire = d3.scaleLinear()
    .domain([0,4500])
    .range([height-margin, 0]);
var nyScale_aire = d3.scaleLinear()
    .domain([0,1])
    .range([height-margin, 0]);
var color = d3.scaleOrdinal(d3.schemeCategory10);

var chart_sem_altillo = d3.select("#chart11").append("svg")
    .attr("width", (width+margin)+"px")
    .attr("height", (height+margin)+"px")
    .append('g')
    .attr("transform", `translate(${mar2}, ${mar2})`);
var chart_aire_temp =  d3.select("#chart22").append("svg")
    .attr("width", (width+margin)+"px")
    .attr("height", (height+margin)+"px")
    .append('g')
    .attr("transform", `translate(${mar2}, ${mar2})`);
var chart_aire =d3.select("#chart33").append("svg")
    .attr("width", (width+margin)+"px")
    .attr("height", (height+margin)+"px")
    .append('g')
    .attr("transform", `translate(${mar2}, ${mar2})`);
var line11 =  d3.line()
    .x(d=>xScale(d.date))
    .y(d=> nyScale_sala_temperatura(d.value))
/*Semana*/
var line12=d3.line()
    .x(d=>xScale_sem(d.date))
    .y(d=> yScale_sem_altillo(d.value))
var line13=d3.line()
    .x(d=>xScale_sem(d.date))
    .y(d=> nyScale_sem_altillo(d.value))
/*AIRE_TEMP*/
var line14 =d3.line()
    .x(d=>xScale(d.date))
    .y(d=> yScale_aire_temp(d.value))
var line15 =d3.line()
    .x(d=>xScale(d.date))
    .y(d=> nyScale_aire_temp(d.value))
var line16=d3.line()
    .x(d=>xScale(d.date))
    .y(d=> yScale_aire(d.value))
var line17=d3.line()
    .x(d=>xScale(d.date))
    .y(d=> nyScale_aire(d.value))
let lines7=chart_sem_altillo.append('g')
  .attr('class', 'lines');
let lines8= chart_aire_temp.append('g')
  .attr('class', 'lines');
let lines9 = chart_aire.append('g')
  .attr('class', 'lines');

/*
--------------------------------------------------------------------------------
                                GROUP2 SELECT
--------------------------------------------------------------------------------
*/
  /*ALTILLO SEMANA*/
lines7.selectAll('.line-group15')
  .data(sem_altillo_signal).enter()
  .append('g')
  .attr('class', 'line-group15')
  .on("mouseover", function(d, i) {
      chart_sem_altillo.append("text")
        .attr("class", "title-text")
        .style("fill", color(i))
        .text(d.name)
        .attr("text-anchor", "middle")
        .attr("x", (width-margin)/2)
        .attr("y", 5);
    })
    .on("mouseout", function(d) {
      chart_sem_altillo.select(".title-text").remove();
    })
  .append('path')
  .attr("width","px")
  .attr('class', 'line')
  .attr('d', d => line13(d.values))
  .style('stroke', (d, i) => color(i))
  .style('opacity', lineOpacity)
  .style('fill',(d, i) => color(i));
/*HORNO*/
  lines8.selectAll('.line-group6')
      .data(horno_signal).enter()
      .append('g')
      .attr('class', 'line-group6')
      .on("mouseover", function(d, i) {
          chart_aire_temp.append("text")
            .attr("class", "title-text")
            .style("fill", color(i))
            .text(d.name)
            .attr("text-anchor", "middle")
            .attr("x", (width-margin)/2)
            .attr("y", 5);
      })
      .on("mouseout", function(d) {
          chart_aire_temp.select(".title-text").remove();
      })
      .append('path')
      .attr("width","px")
      .attr('class', 'line')
      .attr('d', d => line15(d.values))
      .style('stroke', (d, i) => color(i))
      .style('opacity', lineOpacity)
      .style('fill',(d, i) => color(i));
/*AIRE*/
/*
lines9.selectAll('.line-group6')
    .data(aire_signal).enter()
    .append('g')
    .attr('class', 'line-group6')
    .on("mouseover", function(d, i) {
        chart_aire.append("text")
          .attr("class", "title-text")
          .style("fill", color(i))
          .text(d.name)
          .attr("text-anchor", "middle")
          .attr("x", (width-margin)/2)
          .attr("y", 5);
    })
    .on("mouseout", function(d) {
        chart_aire.select(".title-text").remove();
    })
    .append('path')
    .attr("width","px")
    .attr('class', 'line')
    .attr('d', d => line17(d.values))
    .style('stroke', (d, i) => color(i))
    .style('opacity', lineOpacity)
    .style('fill',(d, i) => color(i));
/*
-------------------------------------------------------------------------------
                                GROUP3 SELECT
--------------------------------------------------------------------------------
*
    /*HORNO*/
lines8.selectAll('.line-group11')
    .data(wh_sala_temperatura).enter()
    .append('g')
    .attr('class', 'line-group11')
    .on("mouseover", function(d, i) {
        chart_aire_temp.append("text")
          .attr("class", "title-text")
          .style("fill", color("#C70039"))
          .text(d.name)
          .attr("text-anchor", "middle")
          .attr("x", (width-margin)/2)
          .attr("y", 5);
    })
    .on("mouseout", function(d) {
        chart_aire_temp.select(".title-text").remove();
    })
    .append('path')
    .attr('class', 'line')
    .attr('d', d => line11(d.values))
    .style('stroke', (d, i) => color("#741100"))
    .style("stroke-width", lineStroke)
    .style('opacity', lineOpacity)
    .on("mouseover", function(d) {
        d3.selectAll('.line')
					.style('opacity', otherLinesOpacityHover);
        d3.selectAll('.circle2')
    			.style('opacity', circleOpacityOnLineHover);
        d3.select(this)
          .style('opacity', lineOpacityHover)
          .style("stroke-width", lineStrokeHover)
          .style("cursor", "pointer");
      })
    .on("mouseout", function(d) {
        d3.selectAll(".line")
  				.style('opacity', lineOpacity);
        d3.selectAll('.circle1')
  				.style('opacity', circleOpacity);
        d3.select(this)
          .style("stroke-width", lineStroke)
          .style("cursor", "none");
      });
/*SEMANA*/
lines7.selectAll('.line-group')
  .data(sem_altillo_con).enter()
  .append('g')
  .attr('class', 'line-group')
  .on("mouseover", function(d, i) {
      chart_sem_altillo.append("text")
        .attr("class", "title-text")
        .style("fill", color(i))
        .text(d.name)
        .attr("text-anchor", "middle")
        .attr("x", (width-margin)/2)
        .attr("y", 5);
  })
  .on("mouseout", function(d) {
      chart_sem_altillo.select(".title-text").remove();
  })
  .append('path')
  .attr('class', 'line')
  .attr('d', d => line12(d.values))
  .style('stroke', (d, i) => color(i))
  .style("stroke-width", lineStroke)
  .style('opacity', lineOpacity)
  .on("mouseover", function(d) {
      d3.selectAll('.line')
          .style('opacity', otherLinesOpacityHover);
      d3.selectAll('.circle')
          .style('opacity', circleOpacityOnLineHover);
      d3.select(this)
        .style('opacity', lineOpacityHover)
        .style("stroke-width", lineStrokeHover)
        .style("cursor", "pointer");
    })
  .on("mouseout", function(d) {
      d3.selectAll(".line")
          .style('opacity', lineOpacity);
      d3.selectAll('.circle')
          .style('opacity', circleOpacity);
      d3.select(this)
        .style("stroke-width", lineStroke)
        .style("cursor", "none");
  });
/*AIRE*/
lines9.selectAll('.line-group')
  .data(wh_sala_temperatura).enter()
  .append('g')
  .attr('class', 'line-group')
  .on("mouseover", function(d, i) {
      chart_aire.append("text")
        .attr("class", "title-text")
        .style("fill", color(i))
        .text(d.name)
        .attr("text-anchor", "middle")
        .attr("x", (width-margin)/2)
        .attr("y", 5);
  })
  .on("mouseout", function(d) {
      chart_aire.select(".title-text").remove();
  })
  .append('path')
  .attr('class', 'line')
  .attr('d', d => line12(d.values))
  .style('stroke', (d, i) => color(i))
  .style("stroke-width", lineStroke)
  .style('opacity', lineOpacity)
  .on("mouseover", function(d) {
      d3.selectAll('.line')
          .style('opacity', otherLinesOpacityHover);
      d3.selectAll('.circle')
          .style('opacity', circleOpacityOnLineHover);
      d3.select(this)
        .style('opacity', lineOpacityHover)
        .style("stroke-width", lineStrokeHover)
        .style("cursor", "pointer");
    })
  .on("mouseout", function(d) {
      d3.selectAll(".line")
          .style('opacity', lineOpacity);
      d3.selectAll('.circle')
          .style('opacity', circleOpacity);
      d3.select(this)
        .style("stroke-width", lineStroke)
        .style("cursor", "none");
  });

/*
--------------------------------------------------------------------------------
                              GROUP1 SELECT
--------------------------------------------------------------------------------
*/
  /*HORNO*/
  lines8.selectAll('.line-group19')
    .data(wh_horno).enter()
    .append('g')
    .attr('class', 'line-group19')
    .on("mouseover", function(d, i) {
        chart_aire_temp.append("text")
          .attr("class", "title-text")
          .style("fill", color(i))
          .text(d.name)
          .attr("text-anchor", "middle")
          .attr("x", (width-margin)/2)
          .attr("y", 5);
    })
    .on("mouseout", function(d) {
        chart_aire_temp.select(".title-text").remove();
    })
    .append('path')
    .attr('class', 'line')
    .attr('d', d => line14(d.values))
    .style('stroke', (d, i) => color(i))
    .style("stroke-width", lineStroke)
    .style('opacity', lineOpacity)
    .on("mouseover", function(d) {
        d3.selectAll('.line')
  					.style('opacity', otherLinesOpacityHover);
        d3.selectAll('.circle1')
  					.style('opacity', circleOpacityOnLineHover);
        d3.select(this)
          .style('opacity', lineOpacityHover)
          .style("stroke-width", lineStrokeHover)
          .style("cursor", "pointer");
      })
    .on("mouseout", function(d) {
        d3.selectAll(".line")
  					.style('opacity', lineOpacity);
        d3.selectAll('.circle1')
  					.style('opacity', circleOpacity);
        d3.select(this)
          .style("stroke-width", lineStroke)
          .style("cursor", "none");
      });
      /*
--------------------------------------------------------------------------------
      CIRCLES
--------------------------------------------------------------------------------
      */

      /*Altillo Semana*/
      lines7.selectAll("circle-group")
        .data(sem_altillo_signal).enter()
        .append("g")
        .style("fill", (d, i) => color(i))
        .selectAll("circle")
        .data(d => d.values).enter()
        .append("g")
        .attr("class", "circle")
        .on("mouseover", function(d) {
            d3.select(this)
              .style("cursor", "pointer")
              .append("text")
              .attr("class", "text")
              .text(`${d.value}`)
              .attr("x", d => xScale_sem(d.date) + 5)
              .attr("y", d => nyScale_sem_altillo(d.value) - 10);
          })
        .on("mouseout", function(d) {
            d3.select(this)
              .style("cursor", "none")
              .transition()
              .duration(duration)
              .selectAll(".text").remove();
          })
        .append("circle")
        .attr("cx", d => xScale_sem(d.date))
        .attr("cy", d => nyScale_sem_altillo(d.value))
        .attr("r", circleRadius)
        .style('opacity', circleOpacity)
        .on("mouseover", function(d) {
              d3.select(this)
                .transition()
                .duration(duration)
                .attr("r", circleRadiusHover);
            })
          .on("mouseout", function(d) {
              d3.select(this)
                .transition()
                .duration(duration)
                .attr("r", circleRadius);
            });
      lines7.selectAll("circle-group")
        .data(sem_altillo_con).enter()
        .append("g")
        .style("fill", (d, i) => color(i))
        .selectAll("circle")
        .data(d => d.values).enter()
        .append("g")
        .attr("class", "circle")
        .on("mouseover", function(d) {
            d3.select(this)
              .style("cursor", "pointer")
              .append("text")
              .attr("class", "text")
              .text(`${d.value}`)
              .attr("x", d => xScale_sem(d.date) + 5)
              .attr("y", d => yScale_sem_altillo(d.value) - 10);
          })
        .on("mouseout", function(d) {
            d3.select(this)
              .style("cursor", "none")
              .transition()
              .duration(duration)
              .selectAll(".text").remove();
          })
        .append("circle")
        .attr("cx", d => xScale_sem(d.date))
        .attr("cy", d => yScale_sem_altillo(d.value))
        .attr("r", circleRadius)
        .style('opacity', circleOpacity)
        .on("mouseover", function(d) {
              d3.select(this)
                .transition()
                .duration(duration)
                .attr("r", circleRadiusHover);
            })
          .on("mouseout", function(d) {
              d3.select(this)
                .transition()
                .duration(duration)
                .attr("r", circleRadius);
            });


    /*HORNO*/
      lines8.selectAll("circle-group")
        .data(wh_horno).enter()
        .append("g")
        .style("fill", (d, i) => color(i))
        .selectAll("circle1")
        .data(d => d.values).enter()
        .append("g")
        .attr("class", "circle1")
        .on("mouseover", function(d) {
            d3.select(this)
              .style("cursor", "pointer")
              .append("text")
              .attr("class", "text")
              .text(`${d.value}`)
              .attr("x", d => xScale(d.date) + 5)
              .attr("y", d => yScale_aire_temp(d.value) - 10);
        })
        .on("mouseout", function(d) {
            d3.select(this)
              .style("cursor", "none")
              .transition()
              .duration(duration)
                      .selectAll(".text").remove();
        })
        .append("circle")
        .attr("cx", d => xScale(d.date))
        .attr("cy", d => yScale_aire_temp(d.value))
        .attr("r", circleRadius)
        .style('opacity', circleOpacity)
        .on("mouseover", function(d) {
        d3.select(this)
        .transition()
        .duration(duration)
        .attr("r", circleRadiusHover);
        })
        .on("mouseout", function(d) {
          d3.select(this)
            .transition()
            .duration(duration)
            .attr("r", circleRadius);
      });
      lines8.selectAll("circle-group")
        .data(wh_sala_temperatura).enter()
        .append("g")
        .style("fill", (d, i) => color("#741100"))
        .selectAll("circle1")
        .data(d => d.values).enter()
        .append("g")
        .attr("class", "circle1")
        .on("mouseover", function(d) {
            d3.select(this)
              .style("cursor", "pointer")
              .append("text")
              .attr("class", "text")
              .text(`${d.value}`)
              .attr("x", d => xScale(d.date) + 5)
              .attr("y", d => nyScale_sala_temperatura(d.value) - 10);
        })
        .on("mouseout", function(d) {
            d3.select(this)
              .style("cursor", "none")
              .transition()
              .duration(duration)
                      .selectAll(".text").remove();
        })
        .append("circle")
        .attr("cx", d => xScale(d.date))
        .attr("cy", d => nyScale_sala_temperatura(d.value))
        .attr("r", circleRadius)
        .style('opacity', circleOpacity)
        .on("mouseover", function(d) {
        d3.select(this)
        .transition()
        .duration(duration)
        .attr("r", circleRadiusHover);
        })
        .on("mouseout", function(d) {
          d3.select(this)
            .transition()
            .duration(duration)
            .attr("r", circleRadius);
      });


var xAxis = d3.axisBottom(xScale).ticks(24);

var nyAxis_sala_temperatura =  d3.axisRight(nyScale_sala_temperatura).ticks(10);
var xAxis_sem = d3.axisBottom(xScale_sem).ticks(7);
var yAxis_sem_altillo = d3.axisLeft(yScale_sem_altillo).ticks(25);
var nyAxis_sem_altillo = d3.axisRight(nyScale_sem_altillo).ticks(10);
var yAxis_aire_temp =  d3.axisLeft(yScale_aire_temp).ticks(25);
var nyAxis_aire_temp =  d3.axisRight(nyScale_aire_temp).ticks(25);


/*
-------------------
SEMANA Altillo
------------------
*/
chart_sem_altillo.append("g")
      .attr("class", "25x axis")
      .attr("transform", `translate(0, ${height-margin})`)
      .call(xAxis_sem);

chart_sem_altillo.append("g")
    .attr("class", "y5 axis")
    .call(yAxis_sem_altillo)
    .append('text')
    .attr("y", 15)
    .attr("x",20)
    .attr("fill", "#000")
    .text("Wh")
    .attr("transform","translate(0,-25)");
chart_sem_altillo.append("g")
    .attr("class", "y4 axis")
    .attr("transform","translate("+axistransform1+",0)")
    .call(nyAxis_sem_altillo)
    .append('text')
    .attr("y", 15)
    .attr("fill", "#000")
    .text("Mediciones")
    .attr("transform","translate(0,-25)");

/*
---------------------------
AIRE_TEMP
-----------------
*/
chart_aire_temp.append("g")
      .attr("class", "25x axis")
      .attr("transform", `translate(0, ${height-margin})`)
      .call(xAxis);
chart_aire_temp.append("g")
    .attr("class", "y5 axis")
    .call(yAxis_aire_temp)
    .append('text')
    .attr("y", 15)
    .attr("x",20)
    .attr("fill", "#000")
    .text("Wh")
    .attr("transform","translate(-10,-25)");
chart_aire_temp.append("g")
    .attr("class", "y4 axis")
    .attr("transform","translate("+axistransform1+",0)")
    .call(nyAxis_aire_temp)
    .append('text')
    .attr("y", 15)
    .attr("fill", "#000")
    .text("Mediciones")
    .attr("transform","translate(-15,-25)")
chart_aire_temp.append("g")
        .style("fill", (d, i) => color("#741100"))
        .attr("class", "axis_red")
        .attr("transform","translate("+axistransform2+",0)")
        .call(nyAxis_sala_temperatura)
        .append('text')
        .attr("y", 15)
        .text("ºC")
          .attr("transform","translate(0,-25)");


          /*
----------------------------------------
        Value Mouseover animation
----------------------------------------
*/
var divToolTip = d3.select("body").append("div")
      .attr("class", "tooltip")
      .style("opacity", 1e-6);
      function mouseover() {
      divToolTip.transition()
          .duration(700)
          .style("opacity", 1);
      }
      function mouseout() {
      divToolTip.transition()
          .duration(500)
          .style("opacity", 1e-6);
      }
/*
--------------------------------------------------------------------------------
                              LEGEND
--------------------------------------------------------------------------------
*/

var legend1 = chart_sem_altillo.append("g")
      .attr("font-family", "sans-serif")
      .attr("font-size", 10)
      .attr("text-anchor", "end")
      .selectAll("g")
      .data(sem_altillo_con)
        .enter().append("g")
        .attr("transform", function(d, i) { return "translate(60," + i * 26 + ")"; });
var legend2 = chart_aire_temp.append("g")
      .attr("font-family", "sans-serif")
      .attr("font-size", 10)
      .attr("text-anchor", "end")
      .selectAll("g")
      .data(wh_sala_temperatura)
        .enter().append("g")
        .attr("transform", function(d, i) { return "translate(60," + i * 26 + ")"; });
/*ALTILLO*/
 legend1.append("rect")
      .attr("x", width - 20)
      .attr("width", 20)
      .attr("height", 20)
      .attr("fill",(d, i) => color(i) );

  legend1.append("text")
      .attr("x", width - 25)
      .attr("y", 10)
      .attr("dy", "0.4em")
      .text(function(d) { return d.name; });
/*COCINA*/
legend2.append("rect")
     .attr("x", width - 20)
     .attr("width", 20)
     .attr("height", 20)
     .attr("fill",(d, i) => color("#741100") );

 legend2.append("text")
     .attr("x", width - 25)
     .attr("y", 10)
     .attr("dy", "0.4em")
     .text(function(d) { return d.name; });
